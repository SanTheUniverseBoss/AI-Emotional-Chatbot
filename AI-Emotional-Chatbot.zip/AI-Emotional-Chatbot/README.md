# AI Emotional Chatbot

This is a web-based AI Emotional Chatbot with:

- WhatsApp-style chat interface
- Avatars for User 🤵 and Bot 🤖
- Typing indicator
- Emotion detection with emojis (demo/random currently)
- Emotion trend chart
- Persistent chat history (localStorage)
- FastAPI backend for AI responses

## Project Structure

```
AI-Emotional-Chatbot/
├─ backend/
│   ├─ main.py
│   └─ requirements.txt
├─ frontend/
│   └─ index.html
├─ .gitignore
└─ README.md
```

## How to Run

### Backend (FastAPI)
1. Navigate to the backend folder:
```bash
cd backend
```
2. (Optional) create a virtual environment:
```bash
python -m venv .venv
source .venv/bin/activate  # on Windows: .venv\Scripts\activate
```
3. Install dependencies:
```bash
pip install -r requirements.txt
```
4. Start the server:
```bash
uvicorn main:app --reload
```

### Frontend
1. Serve the frontend folder (recommended) to avoid browser restrictions:
```bash
cd frontend
python -m http.server 5500
```
2. Open your browser to:
```
http://127.0.0.1:5500/index.html
```

Make sure the backend is running at `http://127.0.0.1:8000`.

## Notes & Next Steps

- The backend currently returns random demo responses. Replace the logic in `backend/main.py` with a real emotion detector and response generator (e.g., Hugging Face Transformers or OpenAI) for a production-ready system.
- For production, restrict CORS origins and add authentication, logging, and proper error handling.
