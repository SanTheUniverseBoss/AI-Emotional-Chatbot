from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import random

app = FastAPI()

# Allow CORS for frontend (dev only - restrict in production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    user_id: str
    text: str
    history: list = []

@app.post("/chat")
async def chat(req: ChatRequest):
    # Dummy AI response & emotion simulation (replace with ML model later)
    responses = [
        ("Hello! How can I help you today?", "neutral"),
        ("That's amazing! 😄", "joy"),
        ("I am sorry to hear that 😢", "sadness"),
        ("Be careful! 😡", "anger"),
        ("Hmm, that's worrying 😟", "fear"),
    ]
    reply, emotion = random.choice(responses)
    return {"reply": reply, "emotion": {"label": emotion}}
